let a = document.getElementById('a');
let b = document.getElementById('b');
let c = document.getElementById('c');
// console.log(a.innerHTML)
function copyP() {
    console.log(deleteTag(a.innerHTML))
    console.log(deleteTag(b.innerHTML))
    console.log(c.innerHTML)
    b.innerHTML = deleteTag(a.innerHTML) + b.innerHTML + c.innerHTML;

}
function copyCH() {
    console.log(deleteTag(a.innerHTML))
    console.log(deleteTag(b.innerHTML))
    console.log(c.innerHTML)
    b.innerHTML =  b.innerHTML + c.innerHTML;

}
function deleteTag(text) {
    text = text.split('')
    text = text.splice(0, text.indexOf("<")).join().replaceAll(',', '').replaceAll(" ", "")
    return text;
}

