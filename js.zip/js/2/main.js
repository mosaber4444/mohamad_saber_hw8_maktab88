let square = document.getElementById('1');

square.style.backgroundColor = 'red';
square.style.width = '200px';
square.style.height = '100px';
console.log(square)


function hover(a) {
    return a.style.backgroundColor = 'blue'
}
function hover2(a) {
    return a.style.backgroundColor = 'red'
}

