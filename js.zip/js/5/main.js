const pass = document.getElementById('pwd');
let pass2 = document.getElementById('pwd2');
let username = document.getElementById('username');


function log() {
    let m = document.getElementById('usernameMessege');
    if (username.value === "") {
        m.innerHTML = 'لطفا نام کاربری را پر کنید'
        m.style.color = 'red'
        username.style.borderColor = 'red';
    }
    let m1 = document.getElementById('passMessege');
    if (pass.value === "") {
        m1.innerHTML = 'لطفا گزرواژه را وارد کنید'
        m1.style.color = 'red'
        pass.style.borderColor = 'red';
    }
    let m2 = document.getElementById("passMessege2");
    if (pass2.value === "") {
        m2.innerHTML = 'لطفا گزرواژه را وارد کنید'
        m2.style.color = 'red'
        pass2.style.borderColor = 'red';
    }
    //*********************************************************************************************************
    let mess = document.getElementById('a');
    if (pass2.value !== pass.value){
        mess.innerHTML = "پسوردتان برابر نیست !!!!!!!!!"
        mess.style.color = "red"
    }
    if ( pass2.value.length < 8 || pass2.value.length < 8){
        mess.innerHTML = 'پسوورد حداقل باید 8 کاراکتر باشد'
    }

}