let square = document.getElementById('1');

square.style.backgroundColor = 'red';
square.style.width = '200px';
square.style.height = '100px';
console.log(square)


let square2 = document.getElementById('2');

square2.style.backgroundColor = 'red';
square2.style.width = '200px';
square2.style.height = '100px';


