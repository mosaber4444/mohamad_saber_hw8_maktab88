const table = document.createElement('table');
table.innerHTML = 'My text ';
table.style.color = 'red'
table.style.height = '100px';
table.style.width = '100px';
table.style.border = 'none';


const tableTr = document.createElement('tr');
tableTr.innerHTML = 'ad;sfkj;adfj';
table.appendChild(tableTr)

const tableTr2 = document.createElement('tr');
tableTr2.innerHTML = 'ad;sfkj;adfj';
table.appendChild(tableTr2)










document.body.appendChild(table);

